const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('yardim')
        .setDescription('Bot komutlarını gösterir'),
    
    async execute(interaction) {
        await interaction.reply('Komut listesi:\n - /yardim\n - /clear vb.');
    },
};