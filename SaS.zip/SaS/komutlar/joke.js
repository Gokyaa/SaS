const { SlashCommandBuilder } = require('discord.js');
const fetch = require('node-fetch'); // node-fetch@2 yüklü olması gerek

module.exports = {
    data: new SlashCommandBuilder()
        .setName('joke')
        .setDescription('Rastgele bir programlama şakası gönderir.'),
    
    async execute(interaction) {
        try {
            await interaction.deferReply();

            const response = await fetch('https://official-joke-api.appspot.com/jokes/programming/random');
            const data = await response.json();

            if (!data || !data[0]) {
                return await interaction.editReply('Şu anda şaka bulamıyorum, tekrar dene.');
            }

            const joke = `${data[0].setup}\n||${data[0].punchline}||`;

            await interaction.editReply(joke);
        } catch (error) {
            console.error('Şaka çekilirken hata:', error);
            if (interaction.deferred) {
                await interaction.editReply('Üzgünüm, şu anda şaka bulunamıyor.');
            } else {
                await interaction.reply('Üzgünüm, şu anda şaka bulunamıyor.');
            }
        }
    },
};